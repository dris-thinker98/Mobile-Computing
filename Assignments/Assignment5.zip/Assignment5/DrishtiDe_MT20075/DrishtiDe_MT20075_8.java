package com.example.helloworld;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;

@Dao
public interface WiFiDao {
    @Query("SELECT * FROM wifi_table")
    List<WiFiData> getAllWiFiVal();

    @Query("SELECT Room FROM wifi_table WHERE Count > 4 AND SSID LIKE :word AND (avg(RSSI) == :value) GROUP BY Room")
    String getRoomName(String word, int value);

    @Query("SELECT SSID FROM wifi_table WHERE Room LIKE 'Room1'" +
            "AND Room LIKE 'Room2'" +
            "AND ROOM LIKE 'Room3'")
    String getSSIDforAllRooms();

    @Query("SELECT avg(RSSI) FROM wifi_table WHERE SSID LIKE :name GROUP BY Room")
    String getAvgRSSI(String name);

    @Insert
    void insert(WiFiData wiFiData);
}
