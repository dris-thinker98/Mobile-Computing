package com.example.helloworld;

import android.annotation.SuppressLint;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.wifi.ScanResult;
import android.net.wifi.WifiManager;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import java.util.Arrays;
//import com.google.common.primitives.Ints;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class WifiReceiverCheck extends BroadcastReceiver {

    WifiManager wifiManager;
    StringBuilder sb;
    //ListView wifiDeviceList;
    TextView result;

    public WifiReceiverCheck(WifiManager wifiManager, TextView result) {
        this.wifiManager = wifiManager;
        this.result = result;
    }

    @SuppressLint("SetTextI18n")
    public void onReceive(Context context, Intent intent) {
        String action = intent.getAction();
        if (WifiManager.SCAN_RESULTS_AVAILABLE_ACTION.equals(action)) {
            sb = new StringBuilder();
            List<ScanResult> wifiList = wifiManager.getScanResults();

            ArrayList<String> deviceList = new ArrayList<>();

            for (ScanResult scanResult : wifiList) {
                //sb.append("\n").append(scanResult.SSID).append(" - ").append(scanResult.capabilities);
                //deviceList.add(scanResult.SSID + " - " + scanResult.capabilities);
                String name = scanResult.SSID;
                int value = scanResult.level;

                //Predicting Room using Knn where K is the number of rooms (clusters)

                String ssids = WiFiDatabase.getDatabase(context)
                        .wiFiDao()
                        .getSSIDforAllRooms();
                String[] names = ssids.split(",");
                String wifi = names[0]; //Gets main stable wifi AP

                String valss = WiFiDatabase.getDatabase(context)
                        .wiFiDao()
                        .getAvgRSSI(wifi); //Gets different RSSI values from different rooms (Room 1,2,3)

                String valarray[] = valss.split(",");
                //String resroom[] = roomies.split(",");
                int k = valarray.length;

                float[] dist = new float[k];
                float[] temp = new float[k]; //temp float array to find out min distance
                String[] roomss = new String[k];

                for (int i=0; i<k ;i++){
                    int num = Integer.valueOf(valarray[i]); //taking different avg RSSI values for rooms separately for main wifi AP
                    if(name.equals(wifi)){
                        //Calculate euclidean distance
                        float distance = (float) Math.sqrt((num-value)*(num-value));
                        dist[i] = distance;
                        roomss[i] = WiFiDatabase.getDatabase(context)
                                .wiFiDao()
                                .getRoomAvgRSSI(num,wifi); //getting respective room for the avg(RSSI)
                    }
                }

                ArrayList<Float> clist = new ArrayList<>();
                Arrays.sort(temp);                                  //sorting to find minimum distance
                // adding elements of array
                // to ArrayList
                for (float ii : dist)
                    clist.add(ii);

                // returning index of the element
                int index = clist.indexOf(temp[0]);             //finding index of the minimum distance

                result.setText("You are in " + roomss[index]);          //predicting room name from the index

                /*if((num >= -50) && (num <= -40)){
                    String rname = WiFiDatabase.getDatabase(context)
                            .wiFiDao()
                            .getRoomName(wifi,num);
                    result.setText("You are in " + rname);
                }
                else if(num <= -60){
                    String rname = WiFiDatabase.getDatabase(context)
                            .wiFiDao()
                            .getRoomName(wifi,num);
                    result.setText("You are in " + rname);
                }
                else if(num >= -38){
                    String rname = WiFiDatabase.getDatabase(context)
                            .wiFiDao()
                            .getRoomName(wifi,num);
                    result.setText("You are in " + rname);
                }*/

            }
            //Toast.makeText(context, sb, Toast.LENGTH_SHORT).show();

            //ArrayAdapter arrayAdapter = new ArrayAdapter(context, android.R.layout.simple_list_item_1, deviceList.toArray());

            //wifiDeviceList.setAdapter(arrayAdapter);
        }
    }
}