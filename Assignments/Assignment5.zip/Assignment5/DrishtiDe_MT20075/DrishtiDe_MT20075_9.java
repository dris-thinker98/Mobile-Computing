package com.example.helloworld;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

import java.sql.Timestamp;
import java.util.ArrayList;

@Entity(tableName = "wifi_table")
public class WiFiData {
    @PrimaryKey(autoGenerate = true)
    private int id;

    @ColumnInfo(name = "Room")
    private String room;

    @ColumnInfo(name = "SSID")
    private String name;

    @ColumnInfo(name = "RSSI")
    private String vals;

    @ColumnInfo(name = "Count")
    private int count;

    @ColumnInfo(name = "Timestamp")
    private String tm;

    public WiFiData(String room, String name, String vals, int count, String tm){
        this.room = room;
        this.name = name;
        this.vals = vals;
        this.count = count;
        this.tm = tm;
    }

    //getters
    public int getId() {
        return id;
    }

    public String getRoom() {
        return room;
    }

    public String getName() {
        return name;
    }

    public String getVals() {
        return vals;
    }

    public int getCount() {
        return count;
    }

    public String getTm() {
        return tm;
    }

    //setters
    public void setId(int id) {
        this.id = id;
    }

    public void setRoom(String room) {
        this.room = room;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setVals(String vals) {
        this.vals = vals;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public void setTm(String tm) {
        this.tm = tm;
    }
}