package com.example.helloworld;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.github.mikephil.charting.charts.BarChart;

import java.sql.Timestamp;
import java.util.ArrayList;

public class ListFragment extends Fragment {

    //private BarChart barchart;
    //private ListView wifiList;
    RecyclerView recyclerView;
    ListAdapter recyclerAdapter;
    private WifiManager wifiManager;
    private Button buttonScan;
    private EditText roomName;
    private Button save;
    private Button nxt;
    ArrayList<String> devicelist;

    private final int MY_PERMISSIONS_ACCESS_COARSE_LOCATION = 1;

    private WifiReceiver receiverWifi;
    public ListFragment() {
        // Required empty public constructor
    }
    /*public ListFragment(ArrayList<String> list) {
        // Required empty public constructor
        this.devicelist = list;
    }*/
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable  ViewGroup container,
                             @Nullable  Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.list_fragment, container, false);

        //barchart = getView().findViewById(R.id.barchart);
        recyclerView= view.findViewById(R.id.recycler);
        buttonScan = view.findViewById(R.id.scanBtn2);
        roomName = view.findViewById(R.id.roomName);
        save = view.findViewById(R.id.saveData);
        nxt = view.findViewById(R.id.next);

        wifiManager = (WifiManager) getActivity().getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        if (!wifiManager.isWifiEnabled()) {
            Toast.makeText(getActivity().getApplicationContext(), "Turning WiFi ON...", Toast.LENGTH_LONG).show();
            wifiManager.setWifiEnabled(true);
        }

        //recyclerAdapter = new ListAdapter(getContext(), devicelist);
        /*recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        if(recyclerAdapter != null)
        {
            recyclerAdapter.notifyDataSetChanged();
        }
        recyclerView.setAdapter(recyclerAdapter);*/

        buttonScan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (ActivityCompat.checkSelfPermission(getActivity(), Manifest.permission.ACCESS_COARSE_LOCATION)
                        != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(
                            getActivity(),
                            new String[]{Manifest.permission.ACCESS_COARSE_LOCATION}, MY_PERMISSIONS_ACCESS_COARSE_LOCATION
                    );
                } else {
                    wifiManager.startScan();
                }
            }
        });

        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getActivity().getApplicationContext(), "WiFI data saved!", Toast.LENGTH_SHORT).show();
                String room = roomName.getText().toString();
                if(room.equals("")){
                    Toast.makeText(getActivity(), "Please fill room name!", Toast.LENGTH_SHORT).show();
                }
                else{
                    Timestamp timestamp4 = new Timestamp(System.currentTimeMillis());
                    String tt = timestamp4.toString();
                    String wn = tempData.wifiname;
                    String rval = tempData.rssi;
                    int cc = tempData.count;
                    WiFiData wd = new WiFiData(room,wn,rval,cc,tt);
                    WiFiDatabase.getDatabase(getActivity().getApplicationContext())
                            .wiFiDao()
                            .insert(wd);
                }
            }
        });

        nxt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getActivity(),SecondActivity.class);
                startActivity(i);
            }
        });

        return view;
    }

    @Override
    public void onResume() {
        super.onResume();
        receiverWifi = new WifiReceiver(wifiManager, recyclerView, recyclerAdapter);
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION);
        getActivity().registerReceiver(receiverWifi, intentFilter);
        getWifi();
    }

    private void getWifi() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Toast.makeText(getActivity(), "version>=marshmallow", Toast.LENGTH_SHORT).show();
            if (ContextCompat.checkSelfPermission(getActivity(), Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(getActivity(), "location turned off", Toast.LENGTH_SHORT).show();
                ActivityCompat.requestPermissions(getActivity(), new String[]{Manifest.permission.ACCESS_COARSE_LOCATION}, MY_PERMISSIONS_ACCESS_COARSE_LOCATION);
            } else {
                Toast.makeText(getActivity(), "location turned on", Toast.LENGTH_SHORT).show();
                wifiManager.startScan();
            }
        } else {
            Toast.makeText(getActivity(), "scanning", Toast.LENGTH_SHORT).show();
            wifiManager.startScan();
        }
    }

    @Override
    public void onPause() {
        super.onPause();
        getActivity().unregisterReceiver(receiverWifi);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case MY_PERMISSIONS_ACCESS_COARSE_LOCATION:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    Toast.makeText(getActivity(), "permission granted", Toast.LENGTH_SHORT).show();
                    wifiManager.startScan();
                } else {

                    Toast.makeText(getActivity(), "permission not granted", Toast.LENGTH_SHORT).show();
                    return;
                }
                break;
        }
    }
}