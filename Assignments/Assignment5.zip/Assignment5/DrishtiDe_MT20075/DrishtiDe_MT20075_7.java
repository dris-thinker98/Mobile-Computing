package com.example.helloworld;

import java.util.ArrayList;

public class tempData {

    public static int count = 0;
    public static String wifiname = "";
    public static String rssi = "";

    /*public tempData(ArrayList<String> name, ArrayList<Integer> val) {
        wifiname = name;
        rssival = val;
    }*/
}
