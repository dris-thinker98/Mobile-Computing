package com.example.helloworld;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.room.migration.Migration;
import androidx.sqlite.db.SupportSQLiteDatabase;

@Database(entities = {WiFiData.class}, version = 1)
public abstract class WiFiDatabase extends RoomDatabase {
    private static WiFiDatabase INSTANCE;

    public abstract WiFiDao wiFiDao();

    /*static final Migration MIGRATION_1_2 = new Migration(1, 2) {
        @Override
        public void migrate(SupportSQLiteDatabase database) {
            database.execSQL("ALTER TABLE wifi_table"
                    + " ADD COLUMN timestamp VARCHAR");
        }
    };*/

    public static WiFiDatabase getDatabase(Context context) {
        if (INSTANCE == null) {
            INSTANCE = Room.databaseBuilder(context.getApplicationContext(),
                    WiFiDatabase.class, "WiFi-Database")
                    //.addMigrations(MIGRATION_1_2)
                    .allowMainThreadQueries()
                    .build();
        }
        return INSTANCE;
    }

    //public abstract AccelerometerDao AccelerometerDao();
}