package com.example.helloworld;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.wifi.ScanResult;
import android.net.wifi.WifiManager;
import android.telephony.mbms.StreamingServiceInfo;
import android.text.TextUtils;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.utils.ColorTemplate;

import java.util.ArrayList;
import java.util.List;

import static java.security.AccessController.getContext;

class WifiReceiver extends BroadcastReceiver {

    WifiManager wifiManager;
    StringBuilder sb;
    //ListView wifiDeviceList;
    RecyclerView recyclerView;
    ListAdapter recyclerAdapter;
    ListFragment lf;
    //BarChart barchart;

    public WifiReceiver(WifiManager wifiManager, RecyclerView recyclerView, ListAdapter recyclerAdapter) {
        this.wifiManager = wifiManager;
        //this.wifiDeviceList = WifiList;
        this.recyclerView = recyclerView;
        this.recyclerAdapter = recyclerAdapter;
    }

    public void onReceive(Context context, Intent intent) {
        String action = intent.getAction();
        if (WifiManager.SCAN_RESULTS_AVAILABLE_ACTION.equals(action)) {
            sb = new StringBuilder();
            List<ScanResult> wifiList = wifiManager.getScanResults();
            int c = 0;
            //ArrayList<BarEntry> entries = new ArrayList<>();
            //ArrayList<String> labels = new ArrayList<String>();
            ArrayList<String> deviceList = new ArrayList<>();
            ArrayList<String> wname = new ArrayList<>();
            ArrayList<Integer> rssival = new ArrayList<>();
            for (ScanResult scanResult : wifiList) {
                sb.append("\n").append(scanResult.SSID).append(" - ").append(scanResult.level);
                deviceList.add("Name: " + scanResult.SSID + " \nCapability: " + scanResult.capabilities + "\nRSSI: " + scanResult.level);
                wname.add(scanResult.SSID);
                rssival.add(scanResult.level);
                c++;
            }
            String name = TextUtils.join(",", wname);
            String values = TextUtils.join(",", rssival);
            //tempData.wifiname = wname;
            //tempData.rssi = rssival;
            tempData.wifiname = name;
            tempData.rssi = values;
            tempData.count = c;

            Toast.makeText(context, sb, Toast.LENGTH_SHORT).show();
            //lf = new ListFragment(deviceList);
            recyclerAdapter=new ListAdapter(context, deviceList);
            recyclerView.setLayoutManager(new LinearLayoutManager(context));
            if(recyclerAdapter != null)
            {
                recyclerAdapter.notifyDataSetChanged();
            }
            recyclerView.setAdapter(recyclerAdapter);
            //ArrayAdapter arrayAdapter = new ArrayAdapter(context, android.R.layout.simple_list_item_1, deviceList.toArray());

            //wifiDeviceList.setAdapter(arrayAdapter);
        }
    }
}