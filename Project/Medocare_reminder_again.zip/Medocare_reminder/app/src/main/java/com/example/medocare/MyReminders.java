package com.example.medocare;

public class MyReminders {
    public static String[] myreminder=new String[]{"Eat Lutiz Gold","Eat Nurokind","Eat Crocin"};
}
