package com.example.medocare.SetReminder;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.example.medocare.R;

public class AddReminder extends AppCompatActivity {
    Add_reminderFragment remind_frag;
    Add_Google_calendar google_frag;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_addreminder);

        Intent i=getIntent();


        remind_frag=new Add_reminderFragment();
        google_frag=new Add_Google_calendar();
        FragmentManager manager=getSupportFragmentManager();
        FragmentTransaction fragmentTransaction=manager.beginTransaction();
        fragmentTransaction.add(R.id.fragment_add_reminder,remind_frag);
        fragmentTransaction.add(R.id.fragment_add_google,google_frag);
        fragmentTransaction.commit();

    }
}