package com.example.medocare;

public class MyPrescriptions {
    public static String[] prescription=new String[]{"Prescription 10-03-2021","Prescription 28-02-2021","Prescription 13-01-2021"};
    public static String[] number=new String[]{"1","2","3"};
}
