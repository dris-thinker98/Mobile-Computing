package com.example.medocare;

public class User {

    public String name, email;


    public User(String name, String email){
        this.name = name;
        this.email = email;
    }

}
