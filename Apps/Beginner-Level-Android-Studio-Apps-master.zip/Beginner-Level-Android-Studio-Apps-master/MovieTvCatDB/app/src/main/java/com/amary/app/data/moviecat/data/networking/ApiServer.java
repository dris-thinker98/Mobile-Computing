package com.amary.app.data.moviecat.data.networking;

public class ApiServer {
    static final String URL_HEAD = "https://api.themoviedb.org/3/";
    public static final String COVER_IMAGE = "https://image.tmdb.org/t/p/";
    public static final String API_KEY = "ce3747f9814de0e3fc3292c9ef36fcdb";

}
