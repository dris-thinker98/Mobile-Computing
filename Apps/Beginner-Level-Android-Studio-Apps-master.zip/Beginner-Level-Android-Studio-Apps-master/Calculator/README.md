Simple Calculator for Android
=========================

This scripts was written for android.

How to use?
-----------
Just download and open with Android Studio

Screenshot
-----------
![Screenshot.png](Screenshot.png)

License
--------
Free and Open Source, Feel free to use and modified it.

Contact
-------
You can contact me via:
[justudin](http://justudin.com)