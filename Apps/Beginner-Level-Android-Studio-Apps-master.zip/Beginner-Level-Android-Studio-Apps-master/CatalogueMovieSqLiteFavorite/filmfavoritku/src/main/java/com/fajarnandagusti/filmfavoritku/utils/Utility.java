package com.fajarnandagusti.filmfavoritku.utils;

/**
 * Created by Gustiawan on 11/17/2018.
 */

public class Utility {
    public static final String AUTHORITY = "com.fajarnandagusti.cataloguemoviefinal";
    public static final String SCHEME = "content";
}
