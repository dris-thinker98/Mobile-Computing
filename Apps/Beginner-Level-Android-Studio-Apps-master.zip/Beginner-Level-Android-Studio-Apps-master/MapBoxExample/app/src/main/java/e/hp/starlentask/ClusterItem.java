package e.hp.starlentask;

import com.google.android.gms.maps.model.LatLng;

public class ClusterItem {
    LatLng getPosition() {
        return null;
    }

    /**
     * The title of this marker.
     */
    String getTitle() {
        return null;
    }

    /**
     * The description of this marker.
     */
    String getSnippet() {
        return null;
    }
}
