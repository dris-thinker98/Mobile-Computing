package com.ay3524.connectionchange;

public interface InternetCheckCallback {
    void isInternetAvailable(boolean connectivityStatus);
}
