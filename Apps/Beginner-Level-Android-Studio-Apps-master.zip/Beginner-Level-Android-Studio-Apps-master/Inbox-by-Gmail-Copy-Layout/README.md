# Inbox-by-Gmail-Copy-Layout

<p>This is the clone of the Inbox by Gmail app for the Google Udacity India Scholarship's Copy Layout Challenge. In this challenge we have to create an exact replica of some famous apps like Gmail, Whatsapp, Twitter, Instagram etc.</p>

### Screenshots
<br>
<div>
<img width="300" src="Screenshot1.png" style="border:0px;margin:0px;display:inline-block" align="left"/>
<img width="300" src="Screenshot2.png" style="border:0px;margin:0px;display:inline-block" align="right"/>
</div>
<br/>
<div>
<img width="300" src="Screenshot3.png" style="border:0px;margin:0px;display:inline-block" align="left"/>
<img width="300" src="Screenshot4.png" style="border:0px;margin:0px;display:inline-block" align="right"/>
</div>
<div>
<img width="300" src="Screenshot5.png" style="border:0px;margin:0px;display:inline-block" align="left"/>
<img width="300" src="Screenshot6.png" style="border:0px;margin:0px;display:inline-block" align="right"/>
</div>
<p align="center">
<img width="300" src="Screenshot7.png" style="border:0px;margin:0px;display:inline-block" align="center"/>
</p>
