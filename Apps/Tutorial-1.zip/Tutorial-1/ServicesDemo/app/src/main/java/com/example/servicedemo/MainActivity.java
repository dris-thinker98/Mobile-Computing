package com.example.servicedemo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    Button startserv;
    Button stopserv;
    EditText inp;
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        startserv=(Button)findViewById(R.id.startbutton);
        stopserv=(Button)findViewById(R.id.stopbutton);
        inp=(EditText)findViewById(R.id.inpedittext);
        Intent startintent=new Intent(this,exampleservice.class);
        Intent stopintent=new Intent(this,exampleservice.class);
        startserv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String input=inp.getText().toString();
                startintent.putExtra("extrastring",input);
                startService(startintent);


            }
        });
        stopserv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stopService(stopintent); 
            }
        });
    }
}