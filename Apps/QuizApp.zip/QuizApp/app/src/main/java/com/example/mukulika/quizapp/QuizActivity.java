package com.example.mukulika.quizapp;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

public class QuizActivity extends AppCompatActivity {

    private Button mTrueButton;
    private Button mFalseButton;
    private ImageButton mNextButton;
    private TextView mQuestionTextView;
    private static final String DEBUG_TAG= "QuizActivity";
    private Question[] mQuestionBank = new Question[]{
            new Question(R.string.question_australia,true),
            new Question(R.string.question_oceans,true),
            new Question(R.string.question_mideast,false),
            new Question(R.string.question_africa,false),
            new Question(R.string.question_americas,true),
            new Question(R.string.question_asia,true),
    };
    private  int mCurrentIndex = 0;
    private int requestQode=0;
    private boolean wasAnswerShown=false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz);
        if(savedInstanceState!=null){
            mCurrentIndex=savedInstanceState.getInt("questionId");
        }
        Log.d(DEBUG_TAG,"last question id="+mCurrentIndex);
        mQuestionTextView =(TextView)findViewById(R.id.question_text_view);
        //mQuestionTextView.setText(mQuestionBank[mCurrentIndex].getTextResId());
        mTrueButton =(Button) findViewById(R.id.true_button);
        mFalseButton = (Button)findViewById(R.id.false_button);
        mTrueButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Toast.makeText(QuizActivity.this, R.string.correct_toast,Toast.LENGTH_SHORT).show();
                checkAnswer(true);
            }
        });
        mFalseButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               // Toast.makeText(QuizActivity.this, R.string.incorrect_toast, Toast.LENGTH_SHORT).show();
                checkAnswer(false);
            }
        });
        mNextButton= (ImageButton) findViewById(R.id.next_button);
        mNextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                updateQuestion();
            }
        });
    }

    private void updateQuestion(){
        Log.d(DEBUG_TAG, "Updating Question Text", new Exception());
        mCurrentIndex=(mCurrentIndex + 1) % mQuestionBank.length;
        mQuestionTextView.setText(mQuestionBank[mCurrentIndex].getTextResId());

    }
    private void checkAnswer(boolean pressed){
        int msgId;
        if(wasAnswerShown){
            msgId=R.string.judgement_toast;
        }
        else {
            boolean answer = mQuestionBank[mCurrentIndex].isAnswerTrue();
            if (answer == pressed) {
                msgId = R.string.correct_toast;
            } else {
                msgId = R.string.incorrect_toast;
            }
        }
        Toast.makeText(QuizActivity.this,msgId, Toast.LENGTH_SHORT).show();
    }
    @Override
    public void onSaveInstanceState(Bundle savedInstanceState){
        super.onSaveInstanceState(savedInstanceState);
        savedInstanceState.putInt("questionId",mCurrentIndex);
    }
    public void Cheat(View v){
        Intent intent = new Intent(QuizActivity.this,CheatActivity.class);
        intent.putExtra("questionId",mCurrentIndex);
        boolean answer = mQuestionBank[mCurrentIndex].isAnswerTrue();
        intent.putExtra("answer",answer);
        startActivityForResult(intent,requestQode);
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data){
    if(resultCode!= Activity.RESULT_OK)
        return;
    if(requestCode==requestQode){
        if(data==null){
            return;
        }
        wasAnswerShown=data.getBooleanExtra("answerShown",false);
        //checkAnswer(wasAnswerShown);
    }
    }
}
