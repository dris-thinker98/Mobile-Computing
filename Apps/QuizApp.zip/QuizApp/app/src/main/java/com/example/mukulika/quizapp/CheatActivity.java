package com.example.mukulika.quizapp;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class CheatActivity extends AppCompatActivity {

    private final static String DEBUG_TAG="CheatActivity";
    private int mCurrentQid;
    private boolean answer;
    private TextView mAnswerTextVew;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cheat);
        Intent intent = getIntent();
        mCurrentQid= intent.getIntExtra("questionId",-1);
        answer = intent.getBooleanExtra("answer",false);
        mAnswerTextVew =(TextView)findViewById(R.id.answer_text);
        //setAnswerShownResult(false);
    }
    public void showAnswer(View v){
        if(answer) {
            mAnswerTextVew.setText(R.string.true_button);
        }
        else{
            mAnswerTextVew.setText(R.string.false_button);
        }
        Log.d(DEBUG_TAG, "You Cheated");
        Toast.makeText(this,"You Cheated for Q.No "+mCurrentQid, Toast.LENGTH_SHORT).show();
        setAnswerShownResult(true);
    }
    private void setAnswerShownResult(boolean isAnswerShown){
        Intent data = new Intent();
        data.putExtra("answerShown",true);
        setResult(Activity.RESULT_OK,data);
    }
}
