package mchehab.com.knearestneighbor;

public class Constants {
    public static final String DISTANCE_ALGORITHM = "distanceAlgorithm";
    public static final String K = "K";
    public static final String SPLITE_RATIO = "splitRatio";
    public static final String MINKOWSKI_P = "P";
}
