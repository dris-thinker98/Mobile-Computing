package mchehab.com.knearestneighbor;

public enum Category {
    RED, BLUE, TEST
}