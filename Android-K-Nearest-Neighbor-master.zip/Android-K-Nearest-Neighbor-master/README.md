This is a Java and Kotlin implementation of the KNN classifier. The repo was created for educaitonal purposes only and a proof of concept 
for running a classifier (training and testing) on an Android device.  
A thorough step-by-step overview can be found [here](http://mobiledevhub.com/2018/10/16/android-implementing-knn/).  
Feel free to send your feedback or suggest new ideas to implement in Android.
