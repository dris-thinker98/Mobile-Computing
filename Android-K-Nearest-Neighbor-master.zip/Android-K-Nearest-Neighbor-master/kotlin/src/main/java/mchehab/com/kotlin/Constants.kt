package mchehab.com.kotlin

object Constants {
    val DISTANCE_ALGORITHM = "distanceAlgorithm"
    val K = "K"
    val SPLITE_RATIO = "splitRatio"
    val MINKOWSKI_P = "P"
}