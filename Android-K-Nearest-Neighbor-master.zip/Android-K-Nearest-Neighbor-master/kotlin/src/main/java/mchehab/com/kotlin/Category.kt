package mchehab.com.kotlin

enum class Category {
    RED, BLUE, TEST
}