package com.example.helloworld;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.os.Bundle;
import android.widget.Toast;

public class MainActivity2 extends AppCompatActivity {
    TextView tv;
    Button buttonCheck;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        tv=(TextView) findViewById(R.id.textViewPersonInfo);
        buttonCheck=(Button)findViewById(R.id.buttonCheck);

        Intent i=getIntent();
        String cost=i.getStringExtra("Infor");
        tv.setText(cost);

        buttonCheck.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int cnt= i.getIntExtra("Count",1);
                String stat = "You are Unsafe :( \nPlease follow all precautions!";
                if(cnt==5)
                {
                    stat = "Congrats, you are Safe! ";
                }

                Intent intent = new Intent();
                intent.putExtra("Status", stat);
                setResult(RESULT_OK, intent);
                finish();
            }
        });

    }
    @Override
    protected void onResume() {
        super.onResume();
        mt("Activity2 Resumed");
    }

    @Override
    protected void onPause() {
        super.onPause();
        mt("Activity2 Paused");
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        mt("Activity2 Restarted");
    }

    @Override
    protected void onStart() {
        super.onStart();
        mt("Activity2 Started");
    }

    @Override
    protected void onStop() {
        mt("Activity2 Stopped");
        super.onStop();
    }

    @Override
    protected void onDestroy() {
        mt("Activity2 Destroyed");
        super.onDestroy();
    }

    public void mt(String string){
        Toast.makeText(this, string, Toast.LENGTH_SHORT).show();
    }
}