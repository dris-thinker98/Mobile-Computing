# cse535-mc-startercode
CSE535 - Mobile Computing @ IIITD: Starter Code for Sample Assignment on GitHub classroom

## Assignment Details
- Change the "Hello World" string in Main activity to also print your name.
